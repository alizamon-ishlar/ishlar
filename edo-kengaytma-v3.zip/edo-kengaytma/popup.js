const $ = id => document.getElementById(id);
const esc = s => String(s == null ? '' : s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function vaqt(ms) {
  const d = Math.round((Date.now() - ms) / 60000);
  return d < 1 ? 'hozirgina' : d < 60 ? d + ' daqiqa oldin' : new Date(ms).toLocaleString('ru-RU');
}

async function chiz() {
  const { oxirgi, daqiqa, sb } = await chrome.storage.local.get(['oxirgi', 'daqiqa', 'sb']);
  $('kirishBlok').classList.toggle('hidden', !!sb);
  $('asosiy').classList.toggle('hidden', !sb);
  $('kim').textContent = sb && sb.email ? sb.email : '';
  $('daqiqa').value = daqiqa || 10;
  if (!sb || !oxirgi) return;
  const h = $('holat');
  if (oxirgi.ok) {
    const f = oxirgi.faol || {};
    h.className = 'holat ok';
    h.innerHTML = `<b>✓ ${(f.ijro || 0) + (f.murojaat || 0)} ta bajarilmagan${oxirgi.kechikkan ? ` · ${oxirgi.kechikkan} kechikkan` : ''}</b>
      <div class="qator"><span>📌 Ijro uchun</span><span>${f.ijro || 0}</span></div>
      <div class="qator"><span>📨 Murojaatlar</span><span>${f.murojaat || 0}</span></div>
      <div class="qator"><span>ℹ️ Ma'lumot uchun (ko'rilmagan)</span><span>${f.malumot || 0}</span></div>
      <small>Yangi: ${oxirgi.yangi || 0} ta · ${vaqt(oxirgi.vaqt)}${oxirgi.qoldi ? ` · yana ${oxirgi.qoldi} ta hujjat fayli navbatda` : ''}</small>
      ${(oxirgi.xatolar || []).length ? `<div class="xabar">${esc(oxirgi.xatolar.join('; '))}</div>` : ''}`;
  } else {
    h.className = 'holat xato';
    h.innerHTML = `<b>⚠ ${oxirgi.kirish ? 'Kirish kerak' : 'Xato'}</b><small>${esc(oxirgi.xabar)}<br>${vaqt(oxirgi.vaqt)}</small>`;
  }
}

$('kirBtn').onclick = async () => {
  const b = $('kirBtn'); b.disabled = true; b.textContent = 'Kirilmoqda…'; $('kxabar').textContent = '';
  const r = await chrome.runtime.sendMessage({ tur: 'kirish', email: $('email').value.trim(), parol: $('parol').value });
  b.disabled = false; b.textContent = 'Kirish'; $('parol').value = '';
  if (r && r.xato) $('kxabar').textContent = r.xato;
  chiz();
};

$('hozir').onclick = async () => {
  const b = $('hozir'); b.disabled = true; b.textContent = 'Tekshirilmoqda…';
  await chrome.runtime.sendMessage('hozir');
  b.disabled = false; b.textContent = '↻ Hozir tekshirish';
  chiz();
};
$('saqla').onclick = async () => {
  await chrome.storage.local.set({ daqiqa: Math.max(2, Number($('daqiqa').value) || 10) });
  await chrome.runtime.sendMessage('qayta-jadval');
  $('saqla').textContent = '✓ Saqlandi'; setTimeout(() => $('saqla').textContent = 'Saqlash', 1500);
};
$('tarix').onclick = async () => {
  $('tarix').textContent = 'Yuklanmoqda…';
  await chrome.runtime.sendMessage('tarixni-qayta');
  $('tarix').textContent = 'Eski hujjatlarni qayta yuklash'; chiz();
};
$('chiq').onclick = async () => { await chrome.runtime.sendMessage('chiqish'); chiz(); };

chrome.storage.onChanged.addListener(chiz);
chiz();
