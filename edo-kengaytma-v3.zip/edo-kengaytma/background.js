/**
 * EDO → Alizamon ishlar (v2): fon jarayoni.
 * Har N daqiqada edo.ijro.uz dagi Ijro uchun / Murojaatlar / Ma'lumot uchun hujjatlarini olib,
 * to'g'ridan-to'g'ri Supabase bazasiga yozadi. Claude limitini ishlatmaydi.
 */
importScripts('edo-yigish.js');

const STANDART = {
  sbUrl: 'https://sahaiisdilulydstrdwd.supabase.co',                 // https://xxxx.supabase.co
  sbKey: 'sb_publishable_NAddx0WzT3KsPRKASwuuHQ_vCdWVvxw',            // anon public kalit (ochiq kalit, maxfiy emas)
  gsUrl: 'https://script.google.com/macros/s/AKfycbzt8rACa66RkoR1VzCaA1oBVjyqGcXRtqoiK8-nN4pVm-LqDKUKpsfOu3M1AURrGigW/exec',
  daqiqa: 10,
  maxFayl: 15
};
const EDO_BOSH = 'https://edo.ijro.uz/workflow/inbox/for-execution/search';
const BOLIM_NOMI = { ijro: 'Ijro uchun', murojaat: 'Murojaat', malumot: "Ma'lumot uchun" };

async function sozlama() {
  const s = await chrome.storage.local.get(['daqiqa']);
  return { ...STANDART, daqiqa: Number(s.daqiqa) || STANDART.daqiqa };
}

/* ---------------- Supabase (kutubxonasiz, oddiy fetch) ---------------- */
async function sessiyaSaqla(j) {
  await chrome.storage.local.set({ sb: {
    access: j.access_token, refresh: j.refresh_token,
    tugaydi: Date.now() + (Number(j.expires_in) || 3600) * 1000, email: j.user && j.user.email, uid: j.user && j.user.id
  } });
}
async function kirish(email, parol) {
  const s = await sozlama();
  const r = await fetch(s.sbUrl + '/auth/v1/token?grant_type=password', {
    method: 'POST', headers: { apikey: s.sbKey, 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, password: parol })
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error_description || j.msg || 'Email yoki parol noto\'g\'ri');
  await sessiyaSaqla(j);
  const men = await sb('/rest/v1/rpc/men', { method: 'POST', body: {} });
  if (!men || !men.azo) {
    await chrome.storage.local.remove('sb');
    throw new Error("Akkaunt faollashtirilmagan — avval saytda taklif kodi bilan ro'yxatdan o'ting");
  }
  await chrome.storage.local.set({ men });
  await chrome.storage.local.remove(['oxirgi', 'tarixOlindi']);
  return { ok: true, email: j.user && j.user.email };
}
async function token() {
  const s = await sozlama();
  const { sb } = await chrome.storage.local.get('sb');
  if (!sb || !sb.refresh) return null;
  if (sb.access && sb.tugaydi - 120e3 > Date.now()) return sb.access;
  const r = await fetch(s.sbUrl + '/auth/v1/token?grant_type=refresh_token', {
    method: 'POST', headers: { apikey: s.sbKey, 'Content-Type': 'application/json' },
    body: JSON.stringify({ refresh_token: sb.refresh })
  });
  if (!r.ok) { if (r.status >= 400 && r.status < 500) await chrome.storage.local.remove('sb'); return null; }
  const j = await r.json();
  await sessiyaSaqla(j);
  return j.access_token;
}
async function sb(path, { method = 'GET', body, headers = {}, raw } = {}) {
  const s = await sozlama();
  const t = await token();
  if (!t) { const e = new Error('KIRISH'); e.kirish = true; throw e; }
  const r = await fetch(s.sbUrl + path, {
    method, body: raw ? body : (body === undefined ? undefined : JSON.stringify(body)),
    headers: { apikey: s.sbKey, Authorization: 'Bearer ' + t, ...(raw ? {} : { 'Content-Type': 'application/json' }), ...headers }
  });
  if (!r.ok) {
    const matn = await r.text().catch(() => '');
    throw new Error('Supabase ' + r.status + ': ' + matn.slice(0, 200));
  }
  const matn = await r.text();             // bo'sh javob (return=minimal) ham bo'lishi mumkin
  try { return matn ? JSON.parse(matn) : null; } catch (e) { return null; }
}
async function hammasi(path) {                 // PostgREST bir martada 1000 qator beradi — sahifalab olamiz
  let all = [];
  for (let off = 0; ; off += 1000) {
    const q = await sb(path + (path.includes('?') ? '&' : '?') + 'limit=1000&offset=' + off);
    all = all.concat(q);
    if (q.length < 1000) return all;
  }
}

/* ---------------- Jadval (alarm) ---------------- */
async function jadvalla() {
  const s = await sozlama();
  await chrome.alarms.clear('edo');
  chrome.alarms.create('edo', { delayInMinutes: 0.2, periodInMinutes: Math.max(2, s.daqiqa) });
}
chrome.runtime.onInstalled.addListener(jadvalla);
chrome.runtime.onStartup.addListener(jadvalla);
chrome.alarms.onAlarm.addListener(a => { if (a.name === 'edo') sinxron().catch(() => {}); });
chrome.runtime.onMessage.addListener((m, _s, javob) => {
  const ok = p => p.then(javob, e => javob({ xato: String(e.message || e) }));
  if (m === 'hozir') { ok(sinxron()); return true; }
  if (m === 'qayta-jadval') { ok(jadvalla().then(() => true)); return true; }
  if (m && m.tur === 'kirish') { ok(kirish(m.email, m.parol).then(r => { sinxron().catch(() => {}); return r; })); return true; }
  if (m === 'chiqish') { ok(chrome.storage.local.remove(['sb', 'oxirgi', 'men', 'tarixOlindi']).then(() => true)); return true; }
  if (m === 'tarixni-qayta') { ok(chrome.storage.local.remove('tarixOlindi').then(() => sinxron())); return true; }
});

function belgi(matn, rang, title) {
  chrome.action.setBadgeText({ text: matn });
  chrome.action.setBadgeBackgroundColor({ color: rang });
  if (title) chrome.action.setTitle({ title });
}
async function holatYoz(h) { await chrome.storage.local.set({ oxirgi: { vaqt: Date.now(), ...h } }); }

async function edoTab() {
  const tabs = await chrome.tabs.query({ url: 'https://edo.ijro.uz/*' });
  let tab = tabs.find(t => t.status === 'complete') || tabs[0];
  if (!tab) tab = await chrome.tabs.create({ url: EDO_BOSH, active: false, pinned: true });
  return yuklanishiniKut(tab.id);
}
async function yuklanishiniKut(tabId) {
  for (let i = 0; i < 40; i++) {
    const t = await chrome.tabs.get(tabId);
    if (t.status === 'complete') { await new Promise(r => setTimeout(r, 2500)); return t; }
    await new Promise(r => setTimeout(r, 750));
  }
  return chrome.tabs.get(tabId);
}
async function yigish(tabId, bor, maxFayl, toliqTarix) {
  const [r] = await chrome.scripting.executeScript({
    target: { tabId }, world: 'MAIN', func: edoYigish, args: [bor, maxFayl, toliqTarix]
  });
  if (!r) throw new Error('edo sahifasida ishga tushmadi');
  if (r.error) throw new Error(r.error.message || String(r.error));
  return r.result;
}

const xavfsizNom = s => String(s || 'hujjat.pdf').replace(/[^A-Za-z0-9._-]+/g, '_').slice(-80) || 'hujjat.pdf';
const sanaYoki = s => (/^\d{4}-\d\d-\d\d$/.test(s || '') ? s : null);
function b64dan(b64) { const s = atob(b64); const u = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) u[i] = s.charCodeAt(i); return u; }

/* ---------------- Asosiy sinxronlash ---------------- */
let ishlayapti = false;
async function sinxron() {
  if (ishlayapti) return { band: true };
  ishlayapti = true;
  try {
    const s = await sozlama();
    if (s.sbUrl.startsWith('__')) throw new Error('Kengaytmada Supabase manzili yozilmagan');
    if (!(await token())) {
      belgi('🔑', '#b54708', 'EDO: kengaytmada Supabase akkauntiga kiring');
      await holatYoz({ ok: false, kirish: true, xabar: 'Supabase akkauntiga kiring (pastdagi forma).' });
      return { kirish: false };
    }

    // Bazada bor hujjatlar
    const bazada = await hammasi('/rest/v1/edo?select=id,toliq,holat');
    const borIds = new Set(bazada.map(r => r.id));
    const toliqlar = bazada.filter(r => r.toliq).map(r => r.id);
    const { tarixOlindi } = await chrome.storage.local.get('tarixOlindi');

    let tab = await edoTab();
    let r = await yigish(tab.id, toliqlar, s.maxFayl, !tarixOlindi);
    if (r && r.login === false) {
      await chrome.tabs.reload(tab.id);
      tab = await yuklanishiniKut(tab.id);
      r = await yigish(tab.id, toliqlar, s.maxFayl, !tarixOlindi);
    }
    if (!r || r.login === false) {
      belgi('!', '#c0262d', "EDO: tizimga kiring (E-imzo bilan)");
      await holatYoz({ ok: false, xabar: "edo.ijro.uz ga kirilmagan. Kirib qo'ying — keyingi tekshiruvda o'zi davom etadi." });
      return { login: false };
    }

    // PDF larni Storage'ga yuklash
    for (const it of r.items) {
      if (!it.fayl || !it.fayl.b64) continue;
      const { sb: ss } = await chrome.storage.local.get('sb');
      const yol = (ss && ss.uid) + '/edo/' + it.doc_id + '/' + xavfsizNom(it.fayl.nom);
      try {
        await sb('/storage/v1/object/fayllar/' + yol, {
          method: 'POST', raw: true, body: new Blob([b64dan(it.fayl.b64)], { type: it.fayl.mime || 'application/pdf' }),
          headers: { 'Content-Type': it.fayl.mime || 'application/pdf', 'x-upsert': 'true' }
        });
        it.fayl_path = yol; it.fayl_nom = it.fayl.nom;
      } catch (e) { it.xato = 'Fayl yuklanmadi: ' + e.message; }
      delete it.fayl;
    }

    // Bazaga yozish: tafsilotli va oddiy qatorlar alohida (bir xil ustunlar bo'lishi shart)
    const asos = it => ({
      id: it.id, bolim: it.bolim, reg: it.reg, raqam: it.raqam, sana: sanaYoki(it.sana), kimdan: it.kimdan,
      rez: it.rez, muddat: sanaYoki(it.muddat), holat: it.holat, oqilgan: it.oqilgan, ijrochilar: it.ijrochilar,
      doc_id: it.doc_id, recipient_id: it.recipient_id, kelgan: it.kelganMs ? new Date(it.kelganMs).toISOString() : null
    });
    const toliqQator = r.items.filter(it => it.mazmun !== undefined).map(it => ({
      ...asos(it), mazmun: it.mazmun, jurnal: it.jurnal, fayl_path: it.fayl_path || null, fayl_nom: it.fayl_nom || null,
      toliq: !it.xato, xato: it.xato || null
    }));
    const oddiy = r.items.filter(it => it.mazmun === undefined).map(asos);
    const yoz = async qatorlar => {
      for (let i = 0; i < qatorlar.length; i += 300) {
        await sb('/rest/v1/edo?on_conflict=egasi,id', {
          method: 'POST', body: qatorlar.slice(i, i + 300),
          headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }
        });
      }
    };
    await yoz(oddiy);
    await yoz(toliqQator);

    // edo ro'yxatidan chiqib ketgan bajarilmaganlar — bajarilgan
    for (const [bolim, toliq] of Object.entries(r.faolToliq || {})) {
      if (!toliq) continue;
      const faollar = r.items.filter(it => it.bolim === bolim && it.holat < 20).map(it => it.id);
      const filtr = faollar.length ? '&id=not.in.(' + faollar.map(encodeURIComponent).join(',') + ')' : '';
      await sb('/rest/v1/edo?bolim=eq.' + bolim + '&holat=lt.20' + filtr, {
        method: 'PATCH', body: { holat: 20 }, headers: { Prefer: 'return=minimal' }
      });
    }

    // Yangi hujjatlar haqida xabar (birinchi to'liq yuklashda emas)
    const yangilar = r.items.filter(it => !borIds.has(it.id) && it.holat < 20);
    if (tarixOlindi && yangilar.length) {
      const qisqa = it => (it.bolim === 'murojaat' ? '📨 ' : it.bolim === 'malumot' ? 'ℹ️ ' : '📌 ') + it.reg + ' — ' + String(it.kimdan || '').slice(0, 60);
      const matn = yangilar.map(it => qisqa(it) + ' (' + BOLIM_NOMI[it.bolim] + ')' +
        (it.mazmun ? '\n' + it.mazmun.slice(0, 200) : '') +
        (it.rez ? '\n✍ ' + it.rez.slice(0, 150) : '') +
        (it.muddat ? '\n⏰ Muddat: ' + it.muddat.split('-').reverse().join('.') : '')).join('\n\n');
      const { men } = await chrome.storage.local.get('men');
      if (men && men.admin) {                      // Telegram — faqat dastur egasiga (Apps Script tokenni tekshiradi)
        fetch(s.gsUrl, {
          method: 'POST', redirect: 'follow', headers: { 'Content-Type': 'text/plain;charset=utf-8' },
          body: JSON.stringify({ fn: 'edoXabar', args: [await token(), '📥 EDO: ' + yangilar.length + ' ta yangi hujjat', matn] })
        }).catch(() => {});
      }
      chrome.notifications.create('edo-' + Date.now(), {
        type: 'basic', iconUrl: 'icon-128.png', title: `EDO: ${yangilar.length} ta yangi hujjat`,
        message: yangilar.slice(0, 3).map(qisqa).join('\n')
      });
    }
    if (!tarixOlindi && !(r.xatolar || []).length) await chrome.storage.local.set({ tarixOlindi: true });

    // Hisob
    const bugun = new Date(Date.now() + 5 * 3600e3).toISOString().slice(0, 10);
    const faol = { ijro: 0, murojaat: 0, malumot: 0 }; let kechikkan = 0;
    r.items.forEach(it => { if (it.holat < 20) { faol[it.bolim]++; if (it.bolim !== 'malumot' && it.muddat && it.muddat < bugun) kechikkan++; } });
    const asosiy = faol.ijro + faol.murojaat;
    belgi(asosiy ? String(asosiy) : '', kechikkan ? '#c0262d' : '#1f3a5f',
      `EDO: ijro ${faol.ijro}, murojaat ${faol.murojaat}, ma'lumot ${faol.malumot}` + (kechikkan ? ` · ${kechikkan} kechikkan` : ''));
    await holatYoz({ ok: true, faol, kechikkan, yangi: tarixOlindi ? yangilar.length : 0, jami: r.items.length,
      qoldi: r.navbatdaQoldi || 0, xatolar: r.xatolar || [], tarix: !tarixOlindi });
    return { ok: true };
  } catch (e) {
    if (e.kirish) {
      belgi('🔑', '#b54708', 'EDO: Supabase akkauntiga qayta kiring');
      await holatYoz({ ok: false, kirish: true, xabar: 'Sessiya tugadi — qayta kiring.' });
      return { kirish: false };
    }
    belgi('×', '#b54708', 'EDO: xato — ' + (e.message || e));
    await holatYoz({ ok: false, xabar: String(e.message || e) });
    throw e;
  } finally {
    ishlayapti = false;
  }
}
